const pack = (date, user, wame) => {
return `┏━🔥࿗ 𝙱𝚛𝚒𝚣𝚊𝚜-𝚋𝚘𝚝 𝚞𝚕𝚝𝚒𝚖𝚊𝚝𝚎 ࿗🔥━┓
║                                                           
║ _*🕐 𝐃𝐚𝐭𝐚 𝐞 𝐡𝐨𝐫𝐚: ${date} 🕐*_
║ _*🙂 𝐔𝐬𝐮𝐚́𝐫𝐢𝐨: ${user} 🙂*_
║ _*🌎 𝐖𝐚𝐦𝐞: ${wame} 🌎*_                                        
║                                                           
┣══════𝑺𝒊𝒈𝒂 𝒏𝒂𝒔 𝒓𝒆𝒅𝒆𝒔 𝒔𝒐𝒄𝒊𝒂𝒊𝒔══════┫
║
║ _*📷 𝐈𝐧𝐬𝐭𝐚𝐠𝐫𝐚𝐦:*_ brizasbot01
║
║ _*🤖𝐆𝐢𝐭𝐡𝐮𝐛:*_
║ _*🌐https://suaurl.com/f31687 🌐*_
║
║ _*📹 𝐘𝐨𝐮𝐭𝐮𝐛𝐞:*_
║ _*🌐https://suaurl.com/c12fe7 🌐*_
║
┗════════════════════════┛
» 🥵𝙾𝚗𝚕𝚢𝚏𝚊𝚗𝚜 𝚎 𝚑𝚎𝚗𝚝𝚊𝚒 𝚗𝚘 𝚖𝚎𝚐𝚊🥵 «

❁❧ *FOTOS DE HENTAI 720MB:* 
_*🌐 https://suaurl.com/55eb2f 🌐*_

❁❧ *PRINCESS STARLING(ONLY FANS)8.36GB:* 
_*🌐 https://suaurl.com/b995e2 🌐*_

❁❧ *ELLES CLUB 28.68GB:* 
_*🌐 https://suaurl.com/8c135b 🌐*_

❁❧ *COCONUTKITTY(ONLY FANS)7.69GB:*
_*🌐 https://suaurl.com/5e91e0 🌐*_

❁❧ *Belle delphine:* 
_*🌐 https://suaurl.com/5c699d 🌐*_

❁❧ *Love Lilah:* 
_*🌐 https://suaurl.com/dbaae7 🌐*_

❁❧ *Hidori:* 
_*🌐 https://suaurl.com/f43f76 🌐*_`
}
exports.pack = pack
