const textcomands = (p) => {
return `𝕾𝖊𝖏𝖆𝖒 𝕭𝖊𝖒-𝖁𝖎𝖓𝖉𝖔𝖘 𝖆𝖔 𝕸𝖊𝖓𝖚 𝖉𝖊 𝕿𝖊𝖝𝖙𝖔 𝖉𝖔
💎 ▁▂▃༻𝕭𝖗𝖎𝖟𝖆𝖘-𝖇𝖔𝖙 2.0༺▃▂▁ 💎
╔════ ❯ 𝓬𝓶𝓭 𝓭𝓮 𝓽𝓮𝔁𝓽𝓸 ❮ ══════════
║ ❯ *${p}glitch* <text1> | <text2>
║ ❯ *${p}ravetext* <text1> | <text2>
║ ❯ *${p}woodtext* <text1> | <text2>
║ ❯ *${p}neon* <text1> | <text2>
║ ❯ *${p}sunset* <text1> | <text2>
║ ❯ *${p}gimage* <text>
║ ❯ *${p}whatis* <text>
║ ❯ *${p}text3d* <text>
╚═══════════════════════════`
}
exports.textcomands = textcomands