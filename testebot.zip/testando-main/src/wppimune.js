const databases = (prefix) => {

return `┏━━•°•❈💥𝚍𝚊𝚝𝚊𝚋𝚊𝚜𝚎 𝚍𝚎 𝚝𝚛𝚊𝚟𝚊💥•°•━┓
║
║ ❁❧ ⏤͟͟͞͞𝘿𝘽 𝘿𝙍𝘼𝙂𝙊𝙉 𝙑❷🐉:
║ 🌐https://suaurl.com/9c59ae 🌐
║
║ ❁❧ 🥶𝐃𝐀𝐓𝐀𝐁𝐀𝐒𝐄 - 𝐊𝐀𝐑𝐋𝐋𝐔𝐒 𝐕𝟔🥶:
║ 🌐https://suaurl.com/f9a181 🌐
║
║ ❁❧ DATABASE NESCAU V12:
║ 🌐https://suaurl.com/b677d8 🌐
║
║ ❁❧ 𝐃𝐁 𝐌𝐙𝐂 𝐕1:
║ 🌐https://suaurl.com/eb043c 🌐
║
┗━━━━━━━━━━━━━━━━━━━━━━━━━┛`
}

exports.databases = databases

const imune = (prefix) => {
return `┏━━•❅•°•❈🌀𝚠𝚙𝚙 𝚒𝚖𝚞𝚗𝚎𝚜🌀•°•❅•━━┓
║ ❁❧ ↯𝐈𝐌𝚯𝐑𝐓∆𝐋⛧𝐗𝐗𝐕𝐈ᬏ᭄: 
║ 🌐https://suaurl.com/9332c7 🌐
║
║ ❁❧ ♔【𝐃𝐄𝐔𝐒⛧𝐌𝐀𝐃⛧𝐏𝐑𝐈𝐕𝐀𝐓𝐄 𝐕3】♞: 
║ 🌐https://suaurl.com/143052 🌐
║
║ ❁❧ DELTA YO EXTREME IMUNE: 
║ 🌐https://suaurl.com/b5b92c 🌐
║
║ ❁❧ 𝐏𝐄𝐓𝐀𝐋𝐀𝐙: 
║ 🌐https://suaurl.com/5f75bf 🌐
║
║ ❁❧ Sϟ𝚣𝚣𝚎 v5 by BERTH MODER: 
║ 🌐https://suaurl.com/b5c98c 🌐
║
║ ❁❧ 𝐓 𝐒 𝐔 𝐊 𝐘: 
║ 🌐https://suaurl.com/e50243 🌐
║
║ ❁❧ VΞGΞTΔ ᮃ: 
║ 🌐https://suaurl.com/46d11c 🌐
║
║ ❁❧ 𝐗𝐗𝐗 𝀈 𝐂𝐇𝐈𝐊𝐄𝐍: 
║ 🌐https://suaurl.com/2d3fd0 🌐
║
║ ❁❧ ᬊ͜͡✪𝑺𝒉𝒂𝒅𝒐𝒘 𝐖𝚨⁹⁹⁹⁺.𝑴𝒂𝒕𝒉𝒆𝒖𝒔 𝑹𝒆𝒎𝒐𝒅𝒔: 
║ 🌐https://suaurl.com/265415 🌐
┗━━━━━━━━━━━━━━━━━━━━━━━━━┛`
}

exports.imune = imune